import streamlit as st
import openai
from datetime import datetime

############################################################# App title ############################################################
st.set_page_config(page_title="Amy")
# Create two columns

col1, col2 = st.columns([2, 4])
# Content for the first column
with col1:
    image_path = "face.jpg"
    st.image(image_path, caption="Hi, I'm Amy!", width=200)

# Content for the second column
with col2:

    ############################################################ Page customization ############################################################
    # Function to initialize OpenAI API with user key
    def initialize_openai(api_key):
        openai.api_key = api_key

    # Function to interact with GPT-3.5 Turbo
    def ask_openai(question, conversation):
        try:
            # Capture the current timestamp when the user sends a message
            user_timestamp = datetime.now()

            # Append the user's question with a timestamp
            conversation.append({"role": "user", "content": question, "timestamp": user_timestamp})

            response = openai.ChatCompletion.create(
                model="gpt-4o",  # Corrected model name
                messages=[
                    {"role": "system", "content": "You are a chatbot to aid depression patients. You will interact with meaningful conversations up to a maximum of 10 sentences. Your role is to steer the conversation towards a better self preserving and self-loving lifestyle. You should also track a score=0, every trigger words used by the patient will increase the score by 1. Once score=10, advise the patient to seek medical help. Be more sympathetic to the patient because you can never understand how he or she feels."},
                    {"role": "user", "content": question},
                ]
            )
            answer = response['choices'][0]['message']['content']

            assistant_timestamp = datetime.now()

            conversation.append({"role": "assistant", "content": answer, "timestamp": assistant_timestamp})

            return answer, conversation
        except Exception as e:
            return f"Error: {str(e)}", conversation  # Return error message and conversation

    ############################################################ Streamlit App ############################################################

    ############################################################# Ask for API key first ############################################################
    api_key = st.text_input("Enter your OpenAI API Key", type="password")

    if api_key:
        # Initialize OpenAI API
        initialize_openai(api_key)

        # Initialize conversation history in session state
        if 'conversation' not in st.session_state:
            st.session_state['conversation'] = []

        if 'input_count' not in st.session_state:
            st.session_state['input_count'] = 0

    ############################################################ Display title for the app ############################################################
        st.title("AMY. Making you feel better and stronger everyday.")

        if "question" not in st.session_state:
            st.session_state.question = ""

        def submit():
            st.session_state.question = st.session_state.widget
            st.session_state.widget = ""

        question = st.text_input("Talk to Amy:", key="widget", on_change=submit)

        question = st.session_state.question

        # question = st.text_input("Talk to Amy:")

        if question:
            # Get the answer from OpenAI and update conversation
            result = ask_openai(question, st.session_state['conversation'])

            if isinstance(result, tuple):  # Check if the result is a tuple
                answer, updated_conversation = result
            else:
                answer = result  # If it's an error message, display it
                updated_conversation = st.session_state['conversation']

            # Update the session state with the new conversation
            st.session_state['conversation'] = updated_conversation
            
            for message in reversed(st.session_state['conversation']):  # Display latest messages at the bottom
                timestamp = message["timestamp"].strftime("%Y-%m-%d %H:%M:%S")

                if message['role'] == 'user':
                    # User's message aligned to the right with custom styles (light green)
                    st.markdown(f"<div style='padding: 10px; background-color: #DCF8C6; border-radius: 10px; margin-bottom: 10px; max-width: 70%; margin-left: auto; word-wrap: break-word;'>"
                                f"<strong>You:</strong> {message['content']}<br><small>{timestamp}</small></div>", unsafe_allow_html=True)
                else:
                    # Assistant's message aligned to the left with custom styles (light gray)
                    st.markdown(f"<div style='padding: 10px; background-color: #F1F1F1; border-radius: 10px; margin-bottom: 10px; max-width: 70%; margin-right: auto; word-wrap: break-word;'>"
                                f"<strong>Amy:</strong> {message['content']}<br><small>{timestamp}</small></div>", unsafe_allow_html=True)

    else:
        st.warning("Please enter your OpenAI API key to start.")
